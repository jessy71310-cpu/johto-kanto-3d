import fs from 'node:fs';
const path = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(path)) throw new Error(`Manifest Android introuvable : ${path}`);
let xml = fs.readFileSync(path, 'utf8');
const activity = /<activity\b([^>]*android:name="\.MainActivity"[^>]*)>/s;
if (!activity.test(xml)) throw new Error('Activité MainActivity introuvable dans le manifeste.');
xml = xml.replace(activity, (match, attrs) => {
  const cleaned = attrs.replace(/\s+android:screenOrientation="[^"]*"/g, '');
  return `<activity${cleaned} android:screenOrientation="landscape">`;
});
fs.writeFileSync(path, xml);
console.log('Orientation paysage verrouillée.');
